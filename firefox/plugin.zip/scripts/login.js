const usernameField = document.getElementById("username");
const submitButton = document.getElementById("submit_button");
if (usernameField.value !== "") {
    submitButton.click();
} 