const elements = document.getElementsByName("search");
if (elements[0]) {
    const search = elements[0];
    search.focus(); // Setzt den Fokus auf das Eingabefeld
    search.addEventListener("keydown", function(event) {
        if (event.key === "Enter") {
            const firstCourse = document.getElementById("page-container-16");
            const firstCourseLink = firstCourse.querySelector("a");
            console.log(firstCourseLink, firstCourse);
        }
    });
}
