const button = document.getElementById("button-Student");
console.log(button, "submit");
button.click();