window.location.href = "https://moodle.dhbw.de/my/courses.php";
